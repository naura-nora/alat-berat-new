<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kategori extends Model
{
    use HasFactory;

    protected $table = 'kategori';
    
    protected $fillable = [
        'nama',
        'deskripsi'
    ];

    // Relasi ke alat
    public function alat()
    {
        return $this->hasMany(Alat::class);
    }
}