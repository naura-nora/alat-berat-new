@extends('layouts.app')

@section('content')

@push('styles')
<link rel="stylesheet" href="{{ asset('css/peminjam.css') }}">
@endpush

<div class="container py-4">

    {{-- Header --}}
    <div class="mb-4">
        <h4 class="fw-semibold text-dark mb-0">Daftar Alat</h4>
    </div>

    {{-- Empty state --}}
    @if($alat->count() == 0)
        <div class="alert alert-warning text-center">
            <i class="fas fa-exclamation-triangle mr-1"></i>
            Tidak ada alat yang tersedia saat ini.
        </div>
    @else

        <div class="row">
            @foreach($alat as $item)
            <div class="col-md-4 mb-4">

                <div class="card h-100 border-0 shadow-sm card-hover">

                    {{-- Gambar dengan posisi relative --}}
                    <div class="position-relative">
                        @if($item->gambar)
                            <img src="{{ asset('images/' . $item->gambar) }}" 
                                 class="card-img-top"
                                 style="height: 220px; width: 100%; object-fit: cover;"
                                 alt="Gambar {{ $item->nama }}">
                        @else
                            <div class="bg-light d-flex align-items-center justify-content-center"
                                 style="height: 220px; width: 100%;">
                                <i class="fas fa-tools fa-4x text-muted"></i>
                            </div>
                        @endif

                        {{-- Badge stok - perbaiki dengan class terpisah --}}
                        <span class="stok-badge {{ $item->stok > 0 ? 'bg-success' : 'bg-secondary' }}">
                            <i class="fas {{ $item->stok > 0 ? 'fa-check-circle' : 'fa-times-circle' }} mr-1"></i>
                            {{ $item->stok > 0 ? 'Tersedia: '.$item->stok : 'Stok Habis' }}
                        </span>
                    </div>

                    <div class="card-body">

                        {{-- Nama & kode --}}
                        <h5 class="fw-semibold mb-1">{{ $item->nama }}</h5>
                        <small class="text-muted d-block mb-2">
                            Kode: {{ $item->kode_alat }}
                        </small>

                        <div class="divider"></div>

                        {{-- Info --}}
                        <div class="d-flex justify-content-between mb-2">
                            <span class="info-label">Stok</span>
                            <span class="info-value">{{ $item->stok }} Unit</span>
                        </div>

                        <div class="d-flex justify-content-between mb-2">
                            <span class="info-label">Harga Sewa</span>
                            <span class="harga-value">
                                Rp {{ number_format($item->harga_sewa, 0, ',', '.') }}
                            </span>
                        </div>

                        {{-- Deskripsi --}}
                        @if($item->deskripsi)
                            <div class="divider"></div>
                            <div>
                                <span class="info-label d-block mb-1">Deskripsi</span>
                                <small class="text-muted">
                                    {{ \Illuminate\Support\Str::limit($item->deskripsi, 110) }}
                                </small>
                            </div>
                        @endif

                    </div>
                </div>

            </div>
            @endforeach
        </div>

        {{-- Pagination --}}
        @if($alat->hasPages())
        <div class="d-flex justify-content-center mt-4">
            {{ $alat->links() }}
        </div>
        @endif

    @endif
</div>

@endsection